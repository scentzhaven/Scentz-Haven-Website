/* ============================================================
   SCENTZ HAVEN — Catalogue
   ============================================================ */

export const CURRENCY = { code: 'USD', symbol: '$' };

export const money = (n) =>
  CURRENCY.symbol + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export const PRODUCTS = [
  {
    id: 'noir',
    name: 'Scentz Haven Noir',
    category: 'perfume',
    tagline: 'Smoked leather, black plum, ember',
    short: 'A nocturnal signature built on smoked leather and black plum — poised, quiet, and impossible to place.',
    description:
      'Noir opens on a cool breath of bergamot before turning inward. Black plum bleeds into smoked leather and a heart of iris, while ember-warm woods hold the base steady for hours. It was composed for evenings that begin late and never quite announce themselves — a fragrance that reads as presence rather than perfume.',
    notes: { top: ['Bergamot', 'Pink Pepper', 'Black Plum'], heart: ['Iris', 'Smoked Leather', 'Clove'], base: ['Vetiver', 'Cashmere Wood', 'Amber'] },
    chips: ['Smoked Leather', 'Black Plum', 'Iris', 'Amber'],
    concentration: 'Extrait de Parfum · 22%',
    longevity: '10–12 hours',
    sizes: [ { label: '50 ml', price: 245 }, { label: '100 ml', price: 365 }, { label: '10 ml Travel', price: 95 } ],
    images: ['noir-1', 'noir-2', 'noir-3'],
    rating: 4.9,
    reviewCount: 214,
    badge: 'Signature',
    reviews: [
      { name: 'Adrienne M.', loc: 'Paris, FR', stars: 5, date: 'June 2026', title: 'The one people stop you for',
        body: 'I have worn this every evening for three months. The leather is soft rather than sharp, and the plum keeps it from ever feeling austere. Three separate strangers have asked what I am wearing.' },
      { name: 'Kwesi B.', loc: 'Accra, GH', stars: 5, date: 'May 2026', title: 'Extraordinary depth',
        body: 'Twelve hours in and the base is still singing. The dry-down on skin is warmer and more resinous than the opening suggests — worth waiting for.' },
      { name: 'Tomas R.', loc: 'Lisbon, PT', stars: 4, date: 'April 2026', title: 'Bold, in the best way',
        body: 'Two sprays is genuinely the limit. Immaculate composition, though I reach for it in cooler months more than warm ones.' }
    ]
  },
  {
    id: 'aura',
    name: 'Scentz Haven Aura',
    category: 'perfume',
    tagline: 'White musk, neroli, sunlit linen',
    short: 'Weightless white musk and neroli — the scent of clean light falling across a quiet room.',
    description:
      'Aura is what remains when everything unnecessary is removed. Neroli and bergamot lift a heart of orange blossom and white tea, settling into skin-warm musk and blond cedar. It wears close and luminous, less a fragrance than a change in the quality of the air around you.',
    notes: { top: ['Neroli', 'Bergamot', 'Green Mandarin'], heart: ['Orange Blossom', 'White Tea', 'Jasmine Petals'], base: ['White Musk', 'Blond Cedar', 'Ambrette'] },
    chips: ['White Musk', 'Neroli', 'White Tea', 'Cedar'],
    concentration: 'Eau de Parfum · 18%',
    longevity: '7–9 hours',
    sizes: [ { label: '50 ml', price: 215 }, { label: '100 ml', price: 320 }, { label: '10 ml Travel', price: 85 } ],
    images: ['aura-1', 'aura-2', 'aura-3'],
    rating: 4.8,
    reviewCount: 186,
    badge: 'Best Seller',
    reviews: [
      { name: 'Ines L.', loc: 'Copenhagen, DK', stars: 5, date: 'July 2026', title: 'My everyday skin scent',
        body: 'Clean without ever smelling like soap. It sits just above the skin and lasts the whole workday. I am on my second bottle.' },
      { name: 'Marcus D.', loc: 'Toronto, CA', stars: 5, date: 'June 2026', title: 'Genuinely unisex',
        body: 'Bought it for my wife and quietly started wearing it myself. The neroli opening is bright but never sweet.' },
      { name: 'Sara K.', loc: 'Dubai, AE', stars: 4, date: 'March 2026', title: 'Perfect for warm climates',
        body: 'Holds beautifully in heat where heavier scents collapse. I would love a 200ml size.' }
    ]
  },
  {
    id: 'bloom',
    name: 'Scentz Haven Bloom',
    category: 'perfume',
    tagline: 'Peony, dewed rose, soft suede',
    short: 'Peony and dewed rose over soft suede — a modern floral with a low, velvet finish.',
    description:
      'Bloom captures the half-hour after rain, when a garden is at its most articulate. Dewed peony and Turkish rose open cool and green, then warm against suede and pink pepper. The result is a floral with weight and shadow — romantic, but never sentimental.',
    notes: { top: ['Peony', 'Lychee', 'Pink Pepper'], heart: ['Turkish Rose', 'Magnolia', 'Violet Leaf'], base: ['Suede', 'White Amber', 'Sandalwood'] },
    chips: ['Peony', 'Turkish Rose', 'Suede', 'Sandalwood'],
    concentration: 'Eau de Parfum · 18%',
    longevity: '7–9 hours',
    sizes: [ { label: '50 ml', price: 225 }, { label: '100 ml', price: 335 }, { label: '10 ml Travel', price: 88 } ],
    images: ['bloom-1', 'bloom-2', 'bloom-3'],
    rating: 4.7,
    reviewCount: 148,
    reviews: [
      { name: 'Priya N.', loc: 'London, UK', stars: 5, date: 'July 2026', title: 'A rose for people who dislike rose',
        body: 'The suede base grounds it completely. It smells expensive and modern rather than powdery or nostalgic.' },
      { name: 'Elena V.', loc: 'Milan, IT', stars: 5, date: 'May 2026', title: 'Spring in a bottle',
        body: 'The opening is startlingly green and real — like standing in a garden after rain. Softens beautifully after an hour.' },
      { name: 'Hannah S.', loc: 'Melbourne, AU', stars: 4, date: 'February 2026', title: 'Lovely, slightly quiet',
        body: 'Gorgeous composition, though I wish it projected a little more in the first hour. The dry-down is worth it.' }
    ]
  },
  {
    id: 'oud',
    name: 'Scentz Haven Oud',
    category: 'perfume',
    tagline: 'Laotian oud, saffron, honeyed resin',
    short: 'Laotian oud and saffron wrapped in honeyed resin — our most opulent and most patient composition.',
    description:
      'Four years in development, Oud is built around a single-origin Laotian oud aged in oak. Saffron and rose absolute cut the density at the opening; honeyed labdanum and benzoin carry it into the night. Rich, resinous and unapologetically opulent — a fragrance meant to be worn sparingly and remembered entirely.',
    notes: { top: ['Saffron', 'Rose Absolute', 'Nutmeg'], heart: ['Laotian Oud', 'Cedarwood', 'Patchouli'], base: ['Labdanum', 'Benzoin', 'Tonka Bean'] },
    chips: ['Laotian Oud', 'Saffron', 'Labdanum', 'Tonka'],
    concentration: 'Extrait de Parfum · 25%',
    longevity: '12+ hours',
    sizes: [ { label: '50 ml', price: 395 }, { label: '100 ml', price: 580 }, { label: '10 ml Travel', price: 145 } ],
    images: ['oud-1', 'oud-2', 'oud-3'],
    rating: 4.9,
    reviewCount: 97,
    badge: 'Limited Release',
    reviews: [
      { name: 'Rashid A.', loc: 'Doha, QA', stars: 5, date: 'June 2026', title: 'Authentic oud, properly done',
        body: 'I grew up around oud and most Western interpretations disappoint. This one does not. The saffron opening is exact and the resin base is faultless.' },
      { name: 'Julian F.', loc: 'New York, US', stars: 5, date: 'April 2026', title: 'Worth every cent',
        body: 'One spray on the wrist lasted through dinner, a flight and the next morning. Astonishing tenacity.' },
      { name: 'Noor H.', loc: 'Amman, JO', stars: 5, date: 'January 2026', title: 'Deeply luxurious',
        body: 'Warm, dense and beautifully balanced. The tonka in the base gives it an almost edible softness at the very end.' }
    ]
  },
  {
    id: 'serenity',
    name: 'Scentz Haven Serenity Diffuser',
    category: 'diffuser',
    tagline: 'White tea, fig leaf, cedar',
    short: 'White tea and fig leaf in hand-glazed stoneware — a calm, continuous presence for quiet rooms.',
    description:
      'Serenity was composed for the rooms where you slow down. White tea and fig leaf drift over soft cedar, released through natural rattan reeds at a rate designed for consistency rather than intensity. The vessel is hand-glazed stoneware, finished in matte ivory, and made to be refilled indefinitely.',
    notes: { top: ['White Tea', 'Green Fig'], heart: ['Fig Leaf', 'Lily of the Valley'], base: ['Cedar', 'Soft Musk'] },
    chips: ['White Tea', 'Fig Leaf', 'Cedar'],
    concentration: 'Reed Diffuser · 200 ml',
    longevity: '12–14 weeks',
    sizes: [ { label: '200 ml', price: 145 }, { label: '400 ml', price: 235 }, { label: 'Refill 200 ml', price: 88 } ],
    images: ['serenity-1', 'serenity-2', 'serenity-3'],
    rating: 4.8,
    reviewCount: 132,
    reviews: [
      { name: 'Claire B.', loc: 'Zurich, CH', stars: 5, date: 'July 2026', title: 'The vessel alone is worth it',
        body: 'Beautiful matte stoneware — it looks like an object, not a product. The scent fills our hallway without ever being loud.' },
      { name: 'Daniel O.', loc: 'Lagos, NG', stars: 5, date: 'May 2026', title: 'Three months and still going',
        body: 'Consistent throw the entire time. I flip the reeds weekly as suggested and it has not faded.' },
      { name: 'Mei T.', loc: 'Singapore, SG', stars: 4, date: 'March 2026', title: 'Subtle and clean',
        body: 'Perfect for a bedroom. If you want something that announces itself in a large open space, size up to the 400ml.' }
    ]
  },
  {
    id: 'amber',
    name: 'Scentz Haven Amber Diffuser',
    category: 'diffuser',
    tagline: 'Amber resin, tonka, warm spice',
    short: 'Amber resin and tonka in smoked glass — golden warmth for living rooms and long evenings.',
    description:
      'Amber is the counterpart to Serenity: deeper, warmer, made for the hours after dark. Amber resin and tonka bean settle over a base of sandalwood and a whisper of cinnamon bark, held in smoked glass with a brushed gold collar. It gives a room the particular warmth of low lamplight.',
    notes: { top: ['Cinnamon Bark', 'Bergamot'], heart: ['Amber Resin', 'Tonka Bean'], base: ['Sandalwood', 'Vanilla Absolute'] },
    chips: ['Amber Resin', 'Tonka', 'Sandalwood'],
    concentration: 'Reed Diffuser · 200 ml',
    longevity: '12–14 weeks',
    sizes: [ { label: '200 ml', price: 155 }, { label: '400 ml', price: 250 }, { label: 'Refill 200 ml', price: 92 } ],
    images: ['amber-1', 'amber-2', 'amber-3'],
    rating: 4.9,
    reviewCount: 118,
    badge: 'New',
    reviews: [
      { name: 'Sophie L.', loc: 'Brussels, BE', stars: 5, date: 'July 2026', title: 'Our home now has a signature',
        body: 'Guests comment every single time. Warm and resinous without any of the sweetness I feared from an amber.' },
      { name: 'Andre P.', loc: 'São Paulo, BR', stars: 5, date: 'June 2026', title: 'Beautiful object, beautiful scent',
        body: 'The smoked glass and gold collar look superb on a console table. The cinnamon is very restrained — more warmth than spice.' },
      { name: 'Yuki M.', loc: 'Kyoto, JP', stars: 5, date: 'April 2026', title: 'Perfect winter companion',
        body: 'Deep and enveloping in the evening. Pairs remarkably well with the Serenity in an adjoining room.' }
    ]
  }
];

export const byId = (id) => PRODUCTS.find((p) => p.id === id);
export const byCategory = (c) => PRODUCTS.filter((p) => p.category === c);

export const SHIPPING = [
  { id: 'standard', name: 'Standard Delivery', sub: '4–6 business days · Signature required', price: 12 },
  { id: 'express',  name: 'Express Delivery',  sub: '2–3 business days · Tracked',            price: 18 },
  { id: 'next',     name: 'Next-Day Courier',  sub: 'Order before 14:00 GMT',                 price: 38 }
];

export const FREE_SHIP_THRESHOLD = 250;
