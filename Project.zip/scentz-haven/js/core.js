/* ============================================================
   SCENTZ HAVEN — Core utilities
   ============================================================ */

export const $  = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

export const reduceMotion = () =>
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ---------- LQIP manifest ---------- */
let LQIP = {};
export async function loadLqip() {
  try {
    const r = await fetch('assets/img/lqip.json');
    LQIP = await r.json();
  } catch (e) { LQIP = {}; }
  return LQIP;
}
export const lqip = (stem) => (LQIP[stem] && LQIP[stem].d) || '';
export const aspect = (stem) => (LQIP[stem] && LQIP[stem].ar) || 1.5;

/** [[fileLabel, realPixelWidth], ...] — only variants that actually exist. */
const variants = (stem) => (LQIP[stem] && LQIP[stem].w) || [[960, 960]];

/**
 * Responsive markup: WebP srcset + JPEG fallback, with an inline LQIP
 * background that blurs up once the real image decodes. Descriptors use
 * true pixel widths so the browser never over-fetches a clamped variant.
 */
export function img(stem, alt, { sizes = '100vw', eager = false, cls = '' } = {}) {
  const v    = variants(stem);
  const jpg  = v.map(([lab, w]) => `assets/img/r/${stem}-${lab}.jpg ${w}w`).join(', ');
  const webp = v.map(([lab, w]) => `assets/img/r/${stem}-${lab}.webp ${w}w`).join(', ');
  const fallback = v[Math.min(1, v.length - 1)][0];
  const ph   = lqip(stem);
  return `<div class="media ${cls}" style="${ph ? `background-image:url('${ph}')` : ''}">
    <img src="assets/img/r/${stem}-${fallback}.jpg" srcset="${jpg}" sizes="${sizes}"
         data-webp="${webp}" alt="${esc(alt)}"
         loading="${eager ? 'eager' : 'lazy'}" decoding="async"
         ${eager ? 'fetchpriority="high"' : ''}>
  </div>`;
}

/** Upgrade to WebP where supported, then fade in on decode. */
export function hydrateImages(root = document) {
  const webpOk = hydrateImages._ok ??= (() => {
    const c = document.createElement('canvas');
    return c.toDataURL && c.toDataURL('image/webp').startsWith('data:image/webp');
  })();

  $$('img[data-webp]', root).forEach((im) => {
    if (im.dataset.done) return;
    im.dataset.done = '1';
    if (webpOk) im.srcset = im.dataset.webp;

    const done = () => {
      im.classList.add('loaded');
      const p = im.parentElement;
      // Drop the blurred placeholder once the real pixels are painted.
      setTimeout(() => { if (p) p.style.backgroundImage = 'none'; }, 1200);
    };
    if (im.complete && im.naturalWidth) done();
    else im.addEventListener('load', done, { once: true });
    im.addEventListener('error', () => im.classList.add('loaded'), { once: true });
  });
}

/* ---------- Scroll reveal ---------- */
let revealIO = null;
export function initReveal(root = document) {
  const items = $$('[data-reveal]:not(.in), .rise:not(.in)', root);
  if (reduceMotion()) { items.forEach((el) => el.classList.add('in')); return; }

  revealIO ??= new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      e.target.classList.add('in');
      revealIO.unobserve(e.target);
    });
  }, { rootMargin: '0px 0px -9% 0px', threshold: 0.06 });

  items.forEach((el) => {
    // Anything already above the fold shows immediately — no flash of empty space.
    const r = el.getBoundingClientRect();
    if (r.top < window.innerHeight * 0.92) el.classList.add('in');
    else revealIO.observe(el);
  });
}

/* ---------- Parallax ---------- */
const parallaxEls = [];
export function initParallax(root = document) {
  if (reduceMotion()) return;
  $$('[data-parallax]', root).forEach((el) => {
    if (el.dataset.pxOn) return;
    el.dataset.pxOn = '1';
    parallaxEls.push({ el, amt: parseFloat(el.dataset.parallax) || 0.12 });
  });
}
export function clearParallax() { parallaxEls.length = 0; }

let ticking = false;
function onScroll() {
  if (ticking) return;
  ticking = true;
  requestAnimationFrame(() => {
    const vh = window.innerHeight;
    for (const { el, amt } of parallaxEls) {
      const r = el.getBoundingClientRect();
      if (r.bottom < -200 || r.top > vh + 200) continue;
      const progress = (r.top + r.height / 2 - vh / 2) / vh; // -1 .. 1
      el.style.transform = `translate3d(0, ${(-progress * amt * 100).toFixed(2)}px, 0)`;
    }
    ticking = false;
  });
}
window.addEventListener('scroll', onScroll, { passive: true });
window.addEventListener('resize', onScroll, { passive: true });

/* ---------- Misc ---------- */
export const stars = (n, size = 13) => {
  const full = Math.round(n);
  return `<span class="stars" aria-hidden="true">${Array.from({ length: 5 }, (_, i) =>
    `<svg viewBox="0 0 24 24" style="width:${size}px;height:${size}px;opacity:${i < full ? 1 : 0.22}"><path d="M12 2.6l2.9 5.9 6.5.95-4.7 4.58 1.11 6.47L12 17.45 6.19 20.5 7.3 14.03 2.6 9.45l6.5-.95z"/></svg>`
  ).join('')}</span>`;
};

export const ICON = {
  search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.6-3.6"/></svg>',
  bag:    '<svg viewBox="0 0 24 24"><path d="M6 8h12l1 12H5L6 8z"/><path d="M9 8V6.5a3 3 0 016 0V8"/></svg>',
  close:  '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  check:  '<svg viewBox="0 0 24 24"><path d="M4 12.5l5 5L20 6.5"/></svg>',
  left:   '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>',
  right:  '<svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>',
  truck:  '<svg viewBox="0 0 24 24"><path d="M2 7h12v9H2zM14 10h4l3 3v3h-7z"/><circle cx="6" cy="18" r="1.6"/><circle cx="17.5" cy="18" r="1.6"/></svg>',
  lock:   '<svg viewBox="0 0 24 24"><rect x="4" y="10" width="16" height="10" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/></svg>',
  leaf:   '<svg viewBox="0 0 24 24"><path d="M20 4C10 4 4 9 4 16c0 2 1 4 1 4s2-9 15-12c0 0-6 3-9 9"/></svg>',
  gift:   '<svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="12" rx="1.5"/><path d="M3 12h18M12 8v12M12 8S9 3 6.5 4.5 9 8 12 8s5.5-2 3-3.5S12 8 12 8z"/></svg>',
  ig:     '<svg viewBox="0 0 24 24"><rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r=".9" fill="currentColor" stroke="none"/></svg>',
  x:      '<svg viewBox="0 0 24 24"><path d="M4 4l16 16M20 4L4 20"/></svg>',
  pin:    '<svg viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-11a7 7 0 10-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/></svg>',
  yt:     '<svg viewBox="0 0 24 24"><rect x="2.5" y="6" width="19" height="12" rx="3.5"/><path d="M10.5 9.6l4.5 2.4-4.5 2.4z"/></svg>'
};

/* ---------- Toast ---------- */
let toastEl, toastT;
export function toast(msg) {
  toastEl ??= (() => {
    const d = document.createElement('div');
    d.className = 'toast';
    d.setAttribute('role', 'status');
    d.setAttribute('aria-live', 'polite');
    document.body.appendChild(d);
    return d;
  })();
  toastEl.innerHTML = `${ICON.check}<span>${esc(msg)}</span>`;
  toastEl.classList.add('on');
  clearTimeout(toastT);
  toastT = setTimeout(() => toastEl.classList.remove('on'), 2600);
}

/* ---------- Focus trap ---------- */
export function trapFocus(container) {
  const sel = 'a[href],button:not([disabled]),input,select,textarea,[tabindex]:not([tabindex="-1"])';
  const onKey = (e) => {
    if (e.key !== 'Tab') return;
    const f = $$(sel, container).filter((el) => el.offsetParent !== null);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  };
  container.addEventListener('keydown', onKey);
  return () => container.removeEventListener('keydown', onKey);
}
