/* ============================================================
   SCENTZ HAVEN — Cart store + drawer
   ============================================================ */
import { $, $$, ICON, esc, toast, trapFocus, reduceMotion, img, hydrateImages } from './core.js';
import { byId, money, SHIPPING, FREE_SHIP_THRESHOLD } from './data.js';

const KEY = 'scentz.cart.v1';
const SHIP_KEY = 'scentz.ship.v1';

const read = (k, fb) => { try { return JSON.parse(localStorage.getItem(k)) ?? fb; } catch { return fb; } };
const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

export const cart = {
  items: read(KEY, []),          // [{ id, size, qty }]
  ship: read(SHIP_KEY, 'standard'),
  subs: new Set(),

  save() { write(KEY, this.items); write(SHIP_KEY, this.ship); this.subs.forEach((f) => f(this)); },
  on(fn) { this.subs.add(fn); return () => this.subs.delete(fn); },

  key: (id, size) => `${id}::${size}`,

  add(id, size, qty = 1) {
    const line = this.items.find((l) => l.id === id && l.size === size);
    if (line) line.qty = Math.min(99, line.qty + qty);
    else this.items.push({ id, size, qty });
    this.save();
  },
  setQty(id, size, qty) {
    const line = this.items.find((l) => l.id === id && l.size === size);
    if (!line) return;
    if (qty <= 0) return this.remove(id, size);
    line.qty = Math.min(99, qty);
    this.save();
  },
  remove(id, size) {
    this.items = this.items.filter((l) => !(l.id === id && l.size === size));
    this.save();
  },
  clear() { this.items = []; this.save(); },

  detailed() {
    return this.items.map((l) => {
      const p = byId(l.id);
      if (!p) return null;
      const s = p.sizes.find((x) => x.label === l.size) || p.sizes[0];
      return { ...l, product: p, size: s.label, unit: s.price, total: s.price * l.qty };
    }).filter(Boolean);
  },
  get count() { return this.items.reduce((n, l) => n + l.qty, 0); },
  get subtotal() { return this.detailed().reduce((n, l) => n + l.total, 0); },
  shipOption() { return SHIPPING.find((s) => s.id === this.ship) || SHIPPING[0]; },
  /** Standard delivery becomes complimentary above the threshold; upgrades always cost. */
  get shipping() {
    if (!this.items.length) return 0;
    const opt = this.shipOption();
    if (opt.id === 'standard' && this.subtotal >= FREE_SHIP_THRESHOLD) return 0;
    return opt.price;
  },
  get freeShipEarned() { return this.subtotal >= FREE_SHIP_THRESHOLD; },
  get total() { return this.subtotal + this.shipping; }
};

/* ---------- Fly-to-cart ---------- */
export function flyToCart(sourceEl) {
  const target = $('#cartBtn');
  if (!target) return;
  // The nav auto-hides on downward scroll — bring it back so the bag (and the
  // item flying into it) is visible. Pin it briefly, because momentum/smooth
  // scrolling keeps firing scroll events that would re-hide it mid-flight.
  const nav = $('#nav');
  if (nav) {
    nav.classList.remove('hidden');
    nav.dataset.pinUntil = String(Date.now() + 1600);
  }
  if (!sourceEl || reduceMotion()) return;
  const s = sourceEl.getBoundingClientRect();
  const t = target.getBoundingClientRect();
  if (!s.width) return;

  // The nav may still be sliding back into place, so derive the bag's resting
  // position from layout (nav is position:fixed at top:0) rather than its
  // mid-transition rect.
  const restY = target.offsetTop + t.height / 2;

  const ghost = document.createElement('div');
  ghost.className = 'fly';
  const im = sourceEl.querySelector('img') || sourceEl;
  ghost.innerHTML = `<img src="${im.currentSrc || im.src}" alt="">`;
  Object.assign(ghost.style, {
    left: `${s.left}px`, top: `${s.top}px`,
    width: `${s.width}px`, height: `${s.height}px`,
    transform: 'translate3d(0,0,0) scale(1)', opacity: '1'
  });
  document.body.appendChild(ghost);

  const dx = t.left + t.width / 2 - (s.left + s.width / 2);
  const dy = restY - (s.top + s.height / 2);
  const scale = Math.max(0.06, 34 / Math.max(s.width, s.height));

  ghost.animate(
    [
      { transform: 'translate3d(0,0,0) scale(1)', opacity: 1, borderRadius: '3px' },
      { transform: `translate3d(${dx * 0.55}px, ${dy * 0.42 - 70}px, 0) scale(${(1 + scale) / 2})`, opacity: 0.92, offset: 0.55 },
      { transform: `translate3d(${dx}px, ${dy}px, 0) scale(${scale})`, opacity: 0, borderRadius: '50%' }
    ],
    { duration: 900, easing: 'cubic-bezier(.5,.02,.3,1)', fill: 'forwards' }
  ).onfinish = () => ghost.remove();

  setTimeout(() => {
    target.classList.add('bump');
    setTimeout(() => target.classList.remove('bump'), 700);
  }, 760);
}

export function addToCart(id, size, qty = 1, sourceEl = null) {
  const p = byId(id);
  if (!p) return;
  const s = size || p.sizes[0].label;
  cart.add(id, s, qty);
  flyToCart(sourceEl);
  toast(`${p.name} · ${s} added to bag`);
}

/* ---------- Drawer ---------- */
let untrap = null;

export function initCartUI() {
  if ($('#cartDrawer')) return;

  const scrim = document.createElement('div');
  scrim.className = 'scrim';
  scrim.id = 'cartScrim';

  const drawer = document.createElement('aside');
  drawer.className = 'drawer';
  drawer.id = 'cartDrawer';
  drawer.setAttribute('role', 'dialog');
  drawer.setAttribute('aria-modal', 'true');
  drawer.setAttribute('aria-label', 'Shopping bag');
  drawer.innerHTML = `
    <div class="drawer-head">
      <h2>Your Bag <span class="muted" id="drawerCount" style="letter-spacing:0"></span></h2>
      <button class="icon-btn" id="cartClose" aria-label="Close bag">${ICON.close}</button>
    </div>
    <div class="drawer-body" id="cartBody"></div>
    <div class="drawer-foot" id="cartFoot"></div>`;

  document.body.append(scrim, drawer);

  scrim.addEventListener('click', closeCart);
  $('#cartClose').addEventListener('click', closeCart);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && drawer.classList.contains('open')) closeCart();
  });

  cart.on(() => { renderBadge(); if (drawer.classList.contains('open')) renderDrawer(); });
  renderBadge();
}

export function openCart() {
  renderDrawer();
  $('#cartScrim').classList.add('open');
  $('#cartDrawer').classList.add('open');
  document.body.classList.add('no-scroll');
  untrap = trapFocus($('#cartDrawer'));
  setTimeout(() => $('#cartClose')?.focus(), 380);
}
export function closeCart() {
  const drawer = $('#cartDrawer');
  const wasOpen = drawer?.classList.contains('open');
  $('#cartScrim')?.classList.remove('open');
  drawer?.classList.remove('open');
  document.body.classList.remove('no-scroll');
  untrap?.(); untrap = null;
  // Only restore focus if the drawer was genuinely open and still owns focus,
  // so route changes don't yank focus to the bag button.
  if (wasOpen && drawer.contains(document.activeElement)) $('#cartBtn')?.focus();
}

export function renderBadge() {
  const el = $('#cartCount');
  if (!el) return;
  const n = cart.count;
  el.textContent = n;
  el.classList.toggle('on', n > 0);
  $('#cartBtn')?.setAttribute('aria-label', `Shopping bag, ${n} item${n === 1 ? '' : 's'}`);
}

function renderDrawer() {
  const body = $('#cartBody'), foot = $('#cartFoot'), cnt = $('#drawerCount');
  if (!body) return;
  const lines = cart.detailed();
  cnt.textContent = lines.length ? `(${cart.count})` : '';

  if (!lines.length) {
    body.innerHTML = `<div class="empty">
        ${ICON.bag}
        <p>Your bag is empty.</p>
        <a class="btn btn-ghost" href="#/perfumes" data-link data-close-cart>Discover Fragrances</a>
      </div>`;
    foot.innerHTML = '';
    body.querySelector('[data-close-cart]')?.addEventListener('click', closeCart);
    return;
  }

  body.innerHTML = lines.map((l) => `
    <div class="line" data-line="${l.id}::${esc(l.size)}">
      <a class="l-img" href="#/product/${l.id}" data-link data-close-cart>
        <img src="assets/img/r/${l.product.images[0]}-480.jpg" alt="${esc(l.product.name)}">
      </a>
      <div>
        <a class="l-name" href="#/product/${l.id}" data-link data-close-cart>${esc(l.product.name)}</a>
        <div class="l-var">${esc(l.size)} · ${money(l.unit)}</div>
        <div class="l-row">
          <div class="qty-sm">
            <button data-dec aria-label="Decrease quantity">−</button>
            <span class="n">${l.qty}</span>
            <button data-inc aria-label="Increase quantity">+</button>
          </div>
          <div class="l-price">${money(l.total)}</div>
        </div>
        <button class="l-remove" data-rm>Remove</button>
      </div>
    </div>`).join('');

  const sub = cart.subtotal;
  const remaining = Math.max(0, FREE_SHIP_THRESHOLD - sub);
  const ship = cart.shipping;

  foot.innerHTML = `
    <div class="ship-meter">
      <div class="track"><div class="fill" style="width:${Math.min(100, (sub / FREE_SHIP_THRESHOLD) * 100)}%"></div></div>
      <p>${remaining > 0
          ? `Add <strong>${money(remaining)}</strong> for complimentary delivery.`
          : 'Complimentary delivery unlocked.'}</p>
    </div>
    <div class="totals">
      <div class="t-row"><span>Subtotal</span><span>${money(sub)}</span></div>
      <div class="t-row">
        <span>Estimated shipping</span>
        <span class="${ship === 0 ? 'free' : ''}">${ship === 0 ? 'Complimentary' : money(ship)}</span>
      </div>
      <div class="t-row grand"><span>Total</span><span>${money(sub + ship)}</span></div>
    </div>
    <a class="btn btn-block btn-lg" href="#/checkout" data-link data-close-cart>Proceed to Checkout</a>
    <p class="center muted" style="font-size:12px;margin:12px 0 0">Taxes calculated at checkout · Complimentary returns</p>`;

  // Animate the meter from 0 on open.
  requestAnimationFrame(() => {
    const f = foot.querySelector('.fill');
    if (f) { const w = f.style.width; f.style.width = '0'; requestAnimationFrame(() => (f.style.width = w)); }
  });

  body.querySelectorAll('.line').forEach((row) => {
    const [id, size] = row.dataset.line.split('::');
    const line = cart.items.find((l) => l.id === id && l.size === size);
    row.querySelector('[data-inc]').onclick = () => cart.setQty(id, size, (line?.qty || 0) + 1);
    row.querySelector('[data-dec]').onclick = () => cart.setQty(id, size, (line?.qty || 0) - 1);
    row.querySelector('[data-rm]').onclick = () => {
      row.classList.add('removing');
      setTimeout(() => cart.remove(id, size), 360);
    };
  });
  body.querySelectorAll('[data-close-cart]').forEach((a) => a.addEventListener('click', closeCart));
}
