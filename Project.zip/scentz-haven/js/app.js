/* ============================================================
   SCENTZ HAVEN — Shell, router, search
   ============================================================ */
import { $, $$, ICON, esc, loadLqip, hydrateImages, initReveal, initParallax, clearParallax, reduceMotion, toast, trapFocus } from './core.js';
import { PRODUCTS, money } from './data.js';
import { cart, initCartUI, openCart, closeCart, addToCart, renderBadge } from './cart.js';
import * as V from './pages.js';

/* ---------- Shell ---------- */
function shell() {
  document.body.insertAdjacentHTML('afterbegin', `
    <a class="skip" href="#view">Skip to content</a>
    <div class="progress" id="prog"></div>

    <header class="nav" id="nav">
      <div class="nav-inner">
        <a class="brand" href="#/" data-link>SCENTZ HAVEN</a>
        <nav class="nav-links" aria-label="Primary">
          <a class="nav-link" href="#/" data-link data-nav="/">Home</a>
          <a class="nav-link" href="#/perfumes" data-link data-nav="/perfumes">Perfumes</a>
          <a class="nav-link" href="#/diffusers" data-link data-nav="/diffusers">Diffusers</a>
          <a class="nav-link" href="#/about" data-link data-nav="/about">About</a>
          <a class="nav-link" href="#/contact" data-link data-nav="/contact">Contact</a>
        </nav>
        <div class="nav-actions">
          <button class="icon-btn" id="searchBtn" aria-label="Search">${ICON.search}</button>
          <button class="icon-btn" id="cartBtn" aria-label="Shopping bag">
            ${ICON.bag}<span class="cart-count" id="cartCount">0</span>
          </button>
          <button class="burger" id="burger" aria-label="Menu" aria-expanded="false">
            <span></span><span></span><span></span>
          </button>
        </div>
      </div>
    </header>

    <div class="mobile-menu" id="mobileMenu">
      ${[['Home', '/'], ['Perfumes', '/perfumes'], ['Diffusers', '/diffusers'], ['About', '/about'], ['Contact', '/contact']]
        .map(([t, h], i) => `<a class="m-link" href="#${h}" data-link style="transition-delay:${90 + i * 55}ms">${t}</a>`).join('')}
      <div class="m-foot">
        <p>care@scentzhaven.com<br>+233 30 000 0000</p>
      </div>
    </div>

    <div class="search-overlay" id="searchOverlay" role="dialog" aria-modal="true" aria-label="Search">
      <div class="search-inner">
        <div class="search-field">
          ${ICON.search}
          <input id="searchInput" type="search" placeholder="Search fragrances…" autocomplete="off" aria-label="Search fragrances">
          <button class="icon-btn" id="searchClose" aria-label="Close search">${ICON.close}</button>
        </div>
        <div class="search-results" id="searchResults"></div>
      </div>
    </div>

    <main id="view"></main>
  `);

  document.body.insertAdjacentHTML('beforeend', footer());
}

function footer() {
  const link = (t, h) => `<li><a href="#${h}" data-link>${t}</a></li>`;
  return `
  <footer class="footer">
    <div class="wrap">
      <div class="f-top">
        <div class="f-brand">
          <div class="b-name">SCENTZ HAVEN</div>
          <p>Luxury fragrance composed slowly in Grasse — for the people you remember and the rooms you return to.</p>
          <div class="socials">
            <a href="#/" data-link aria-label="Instagram">${ICON.ig}</a>
            <a href="#/" data-link aria-label="X">${ICON.x}</a>
            <a href="#/" data-link aria-label="Pinterest">${ICON.pin}</a>
            <a href="#/" data-link aria-label="YouTube">${ICON.yt}</a>
          </div>
        </div>
        <div class="f-col">
          <h4>Shop</h4>
          <ul>
            ${link('All Perfumes', '/perfumes')}${link('All Diffusers', '/diffusers')}
            ${link('Scentz Haven Noir', '/product/noir')}${link('Scentz Haven Oud', '/product/oud')}
            ${link('Discovery Set', '/contact')}
          </ul>
        </div>
        <div class="f-col">
          <h4>Support</h4>
          <ul>
            ${link('Contact Us', '/contact')}${link('Shipping & Delivery', '/terms')}
            ${link('Returns', '/terms')}${link('Fragrance Guide', '/about')}${link('FAQ', '/contact')}
          </ul>
        </div>
        <div class="f-col">
          <h4>House</h4>
          <ul>
            ${link('Our Story', '/about')}${link('Sustainability', '/about')}
            ${link('Press', '/contact')}${link('Stockists', '/contact')}
          </ul>
        </div>
      </div>

      <div class="news">
        <div>
          <h4>Letters from the atelier.</h4>
          <p>New compositions, notes on materials, and private previews. No noise — a few times a year.</p>
        </div>
        <div>
          <form class="news-form" id="newsForm" novalidate>
            <input id="newsEmail" type="email" placeholder="Email address" aria-label="Email address" autocomplete="email">
            <button class="btn" type="submit">Subscribe</button>
          </form>
          <div class="news-ok" id="newsOk">Thank you — please confirm via the email we just sent.</div>
        </div>
      </div>

      <div class="f-bottom">
        <span>© 2026 Scentz Haven. All rights reserved.</span>
        <span class="legal">
          <a href="#/privacy" data-link>Privacy Policy</a>
          <a href="#/terms" data-link>Terms &amp; Conditions</a>
          <a href="#/contact" data-link>Accessibility</a>
        </span>
      </div>
    </div>
  </footer>`;
}

/* ---------- Router ---------- */
const routes = [
  [/^\/$/,                 () => ({ html: V.Home(), title: 'Scentz Haven — Elevate Your Atmosphere' })],
  [/^\/perfumes$/,         () => ({ html: V.Collection('perfume'), title: 'Perfumes — Scentz Haven' })],
  [/^\/diffusers$/,        () => ({ html: V.Collection('diffuser'), title: 'Diffusers — Scentz Haven' })],
  [/^\/product\/([\w-]+)$/, (m) => ({ html: V.Product(m[1]), title: `${m[1]} — Scentz Haven`, bind: () => V.bindProduct(m[1]) })],
  [/^\/about$/,            () => ({ html: V.About(), title: 'Our Story — Scentz Haven' })],
  [/^\/contact$/,          () => ({ html: V.Contact(), title: 'Contact — Scentz Haven', bind: V.bindContact })],
  [/^\/checkout$/,         () => ({ html: V.Checkout(), title: 'Checkout — Scentz Haven', bind: V.bindCheckout })],
  [/^\/confirmed$/,        () => ({ html: V.Confirmed(), title: 'Order Confirmed — Scentz Haven' })],
  [/^\/privacy$/,          () => ({ html: V.Legal('privacy'), title: 'Privacy Policy — Scentz Haven' })],
  [/^\/terms$/,            () => ({ html: V.Legal('terms'), title: 'Terms & Conditions — Scentz Haven' })]
];

const path = () => (location.hash.replace(/^#/, '') || '/').split('?')[0];

let navigating = false;
async function render(push = true) {
  const p = path();
  const found = routes.find(([re]) => re.test(p));
  const view = found ? found[1](p.match(found[0])) : { html: V.NotFound(), title: 'Not Found — Scentz Haven' };

  const el = $('#view');
  const prog = $('#prog');

  // Any open overlay must not survive a route change, or its scrim blocks the new page.
  closeCart();
  $('#searchOverlay')?.classList.remove('open');
  $('#mobileMenu')?.classList.remove('open');
  $('#burger')?.classList.remove('open');
  $('#burger')?.setAttribute('aria-expanded', 'false');
  document.body.classList.remove('no-scroll');

  prog.classList.add('on'); prog.style.width = '38%';

  // Fade out, swap, fade in — the page transition.
  if (!reduceMotion() && el.innerHTML.trim()) {
    el.classList.add('leaving');
    await new Promise((r) => setTimeout(r, 240));
  }

  clearParallax();
  el.innerHTML = view.html;
  el.classList.remove('leaving');
  document.title = view.title;
  prog.style.width = '82%';

  // Restore scroll before paint so the new page never flashes mid-scroll.
  window.scrollTo({ top: 0, behavior: 'instant' in document.documentElement.style ? 'instant' : 'auto' });

  hydrateImages(el);
  initReveal(el);
  initParallax(el);
  view.bind?.();

  el.classList.add('entering');
  requestAnimationFrame(() => {
    el.classList.remove('entering');
    el.classList.add('entered');
    setTimeout(() => el.classList.remove('entered'), 700);
  });

  $$('[data-nav]').forEach((a) => a.classList.toggle('active', a.dataset.nav === p));
  bindViewActions(el);

  prog.style.width = '100%';
  setTimeout(() => { prog.classList.remove('on'); prog.style.width = '0'; }, 320);
}

/** Add/Buy buttons that appear inside rendered views. */
function bindViewActions(root) {
  $$('[data-add]', root).forEach((b) => b.addEventListener('click', (e) => {
    e.preventDefault();
    const media = b.closest('.showcase')?.querySelector('.sc-media') || b.closest('.card')?.querySelector('.thumb');
    addToCart(b.dataset.add, null, 1, media);
  }));
  $$('[data-buy]', root).forEach((b) => b.addEventListener('click', (e) => {
    e.preventDefault();
    const p = PRODUCTS.find((x) => x.id === b.dataset.buy);
    cart.add(p.id, p.sizes[0].label, 1);
    location.hash = '#/checkout';
  }));

  const nf = $('#newsForm');
  if (nf && !nf.dataset.on) {
    nf.dataset.on = '1';
    nf.addEventListener('submit', (e) => {
      e.preventDefault();
      const v = $('#newsEmail').value.trim();
      if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(v)) { toast('Please enter a valid email address'); return; }
      $('#newsOk').classList.add('on');
      $('#newsEmail').value = '';
      toast('Subscribed — welcome to the house');
    });
  }
}

/* ---------- Nav behaviour ---------- */
function initNav() {
  const nav = $('#nav');
  let last = window.scrollY;

  const onScroll = () => {
    const y = window.scrollY;
    nav.classList.toggle('scrolled', y > 12);
    // Respect a temporary pin (e.g. an item flying into the bag).
    const pinned = Number(nav.dataset.pinUntil || 0) > Date.now();
    if (pinned) { nav.classList.remove('hidden'); last = y; return; }
    // Hide on downward scroll past the fold; reveal instantly on the way up.
    if (y > 380 && y > last + 4 && !$('#mobileMenu').classList.contains('open')) nav.classList.add('hidden');
    else if (y < last - 4 || y < 200) nav.classList.remove('hidden');
    last = y;
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  const burger = $('#burger'), menu = $('#mobileMenu');
  const toggleMenu = (open) => {
    burger.classList.toggle('open', open);
    menu.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', String(open));
    document.body.classList.toggle('no-scroll', open);
  };
  burger.addEventListener('click', () => toggleMenu(!menu.classList.contains('open')));
  menu.addEventListener('click', (e) => { if (e.target.closest('a')) toggleMenu(false); });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && menu.classList.contains('open')) toggleMenu(false);
  });

  $('#cartBtn').addEventListener('click', openCart);
}

/* ---------- Search ---------- */
function initSearch() {
  const ov = $('#searchOverlay'), input = $('#searchInput'), out = $('#searchResults');
  let untrap = null;

  const open = () => {
    ov.classList.add('open');
    document.body.classList.add('no-scroll');
    untrap = trapFocus(ov);
    setTimeout(() => input.focus(), 260);
    run('');
  };
  const close = () => {
    ov.classList.remove('open');
    document.body.classList.remove('no-scroll');
    untrap?.(); untrap = null;
    input.value = '';
  };

  const run = (q) => {
    const s = q.trim().toLowerCase();
    const hits = !s ? [] : PRODUCTS.filter((p) =>
      [p.name, p.tagline, p.short, p.category, ...p.chips,
       ...p.notes.top, ...p.notes.heart, ...p.notes.base].join(' ').toLowerCase().includes(s));

    if (!s) {
      out.innerHTML = `
        <div class="eyebrow muted" style="margin-bottom:14px">Popular</div>
        <div class="sugg">
          ${['Oud', 'Amber', 'White Musk', 'Rose', 'Diffuser', 'Travel size']
            .map((t) => `<button class="note" data-sugg="${t}">${t}</button>`).join('')}
        </div>`;
      out.querySelectorAll('[data-sugg]').forEach((b) =>
        b.addEventListener('click', () => { input.value = b.dataset.sugg; run(b.dataset.sugg); input.focus(); }));
      return;
    }

    out.innerHTML = hits.length
      ? hits.map((p, i) => `
          <a class="sr" href="#/product/${p.id}" data-link data-close-search style="animation-delay:${i * 45}ms">
            <div class="sr-img"><img src="assets/img/r/${p.images[0]}-480.jpg" alt=""></div>
            <div><h4>${esc(p.name)}</h4><p>${esc(p.tagline)}</p></div>
            <div>${money(p.sizes[0].price)}</div>
          </a>`).join('')
      : `<p class="muted" style="padding:20px 0">No fragrances match “${esc(q)}”. Try “oud”, “musk” or “diffuser”.</p>`;

    out.querySelectorAll('[data-close-search]').forEach((a) => a.addEventListener('click', close));
  };

  $('#searchBtn').addEventListener('click', open);
  $('#searchClose').addEventListener('click', close);
  input.addEventListener('input', () => run(input.value));
  ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && ov.classList.contains('open')) close();
    // ⌘K / Ctrl-K opens search.
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); open(); }
  });
}

/* ---------- Boot ---------- */
(async function boot() {
  shell();
  await loadLqip();
  initCartUI();
  initNav();
  initSearch();

  // Intercept in-app links so the router owns navigation.
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[data-link]');
    if (!a) return;
    const href = a.getAttribute('href');
    if (!href?.startsWith('#')) return;
    if (href === location.hash) { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  });

  window.addEventListener('hashchange', () => render());
  await render(false);
  renderBadge();
  document.documentElement.classList.add('ready');
})();
