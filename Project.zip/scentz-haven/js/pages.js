/* ============================================================
   SCENTZ HAVEN — Views
   ============================================================ */
import { $, $$, img, esc, stars, ICON, toast, hydrateImages } from './core.js';
import { PRODUCTS, byId, byCategory, money, SHIPPING, FREE_SHIP_THRESHOLD } from './data.js';
import { cart, addToCart, openCart } from './cart.js';

/* ---------- shared fragments ---------- */

const productCard = (p, i = 0) => `
  <a class="card" href="#/product/${p.id}" data-link data-reveal style="--d:${i * 70}ms">
    <div class="thumb">
      ${img(p.images[0], p.name, { sizes: '(max-width:560px) 92vw, (max-width:1024px) 46vw, 30vw' })}
      ${p.badge ? `<span class="sc-tag">${esc(p.badge)}</span>` : ''}
      <span class="quick">View Fragrance</span>
    </div>
    <div class="c-meta">
      <div>
        <h3>${esc(p.name)}</h3>
        <div class="c-sub">${esc(p.tagline)}</div>
      </div>
      <div class="c-price">${money(p.sizes[0].price)}</div>
    </div>
  </a>`;

const showcase = (p, i) => `
  <article class="showcase ${i % 2 ? 'flip' : ''}">
    <a class="sc-media" href="#/product/${p.id}" data-link data-reveal="scale" aria-label="${esc(p.name)}">
      ${p.badge ? `<span class="sc-tag">${esc(p.badge)}</span>` : ''}
      <div class="parallax" data-parallax="0.06" style="position:absolute;inset:-6% 0">
        ${img(p.images[0], p.name, { sizes: '(max-width:860px) 92vw, 46vw' })}
      </div>
    </a>
    <div class="sc-body">
      <div data-reveal="${i % 2 ? 'right' : 'left'}">
        <span class="eyebrow">${p.category === 'perfume' ? 'Fragrance' : 'Home'} · ${esc(p.concentration.split('·')[0].trim())}</span>
        <h3>${esc(p.name)}</h3>
        <p class="sc-desc">${esc(p.short)}</p>
        <div class="notes">${p.chips.map((c) => `<span class="note">${esc(c)}</span>`).join('')}</div>
        <div class="price-row">
          <span class="price">${money(p.sizes[0].price)}</span>
          <span class="price-note">${esc(p.sizes[0].label)} · ${esc(p.longevity)} wear</span>
        </div>
        <div class="sc-actions">
          <button class="btn" data-add="${p.id}">Add to Cart</button>
          <button class="btn btn-ghost" data-buy="${p.id}">Buy Now</button>
          <a class="tlink" href="#/product/${p.id}" data-link style="margin-left:6px">Details <span class="arw">→</span></a>
        </div>
      </div>
    </div>
  </article>`;

/* ============================================================
   HOME
   ============================================================ */
export function Home() {
  const perfumes = byCategory('perfume');
  const diffusers = byCategory('diffuser');
  const bandItems = ['Hand-poured in small batches', 'Complimentary delivery over $250', 'Cruelty-free & IFRA certified', 'Refillable vessels', 'Composed in Grasse, France'];
  const band = bandItems.map((t) => `<span class="band-item"><span class="dot"></span>${esc(t)}</span>`).join('');

  return `
  <section class="hero">
    <div class="hero-bg" data-parallax="0.14">
      <div class="hero-wide">${img('hero', 'Scentz Haven signature perfume bottle in warm daylight', { sizes: '100vw', eager: true })}</div>
      <div class="hero-tall">${img('hero-m', 'Scentz Haven signature perfume bottle in warm daylight', { sizes: '100vw', eager: true })}</div>
    </div>
    <div class="hero-inner">
      <div class="wrap">
        <div class="hero-copy">
          <div class="rise in" style="--d:120ms"><span class="eyebrow">Est. 2016 · Grasse, France</span></div>
          <h1 class="display">
            <span class="rise in" style="--d:220ms"><span>SCENTZ HAVEN</span></span>
          </h1>
          <div class="rise in" style="--d:360ms"><span class="tagline">Elevate Your Atmosphere.</span></div>
          <p class="sub" data-reveal="fade" style="--d:640ms">Luxury fragrances crafted to transform everyday moments into unforgettable experiences.</p>
          <div class="hero-cta" data-reveal style="--d:780ms">
            <a class="btn btn-lg" href="#/perfumes" data-link>Shop Perfumes</a>
            <a class="btn btn-ghost btn-lg" href="#/diffusers" data-link>Explore Diffusers</a>
          </div>
        </div>
      </div>
    </div>
    <div class="scroll-hint"><span>Scroll</span><span class="bar"></span></div>
  </section>

  <div class="band"><div class="band-track">${band}${band}</div></div>

  <section class="section">
    <div class="wrap">
      <div class="s-head center" data-reveal>
        <span class="eyebrow">The Collection</span>
        <h2>Six compositions.<br>Nothing superfluous.</h2>
        <p class="lead">Each fragrance is developed over years, not seasons — then produced in batches small enough to inspect by hand.</p>
      </div>
    </div>
    <div class="wrap">
      ${perfumes.slice(0, 2).map(showcase).join('')}
    </div>
  </section>

  <section class="philosophy">
    <div class="wrap">
      <blockquote class="rise" data-reveal="fade">
        <span class="rise"><span>Your scent. Your space.</span></span>
        <span class="rise" style="--d:140ms"><span>Your haven.</span></span>
      </blockquote>
      <div class="attrib" data-reveal="fade" style="--d:420ms">The Scentz Haven Philosophy</div>
    </div>
  </section>

  <section class="section">
    <div class="wrap">
      ${perfumes.slice(2).map((p, i) => showcase(p, i)).join('')}
    </div>
  </section>

  <section class="section alt">
    <div class="wrap">
      <div class="s-head" data-reveal>
        <span class="eyebrow">Home Fragrance</span>
        <h2>A room should greet you.</h2>
        <p class="lead">Hand-glazed vessels and slow-release reeds, engineered for a consistent throw across twelve to fourteen weeks.</p>
      </div>
      ${diffusers.map((p, i) => showcase(p, i)).join('')}
    </div>
  </section>

  <section class="section">
    <div class="wrap">
      <div class="split">
        <div data-reveal="left">
          <span class="eyebrow">Our Craft</span>
          <h2 class="display" style="font-size:clamp(31px,4.4vw,50px);margin-top:14px">Composed slowly,<br>by hand.</h2>
          <p class="lead mt-s">We work with a single perfumer in Grasse and a small atelier that has been distilling for three generations. Formulas are revised for years before release — and quietly retired rather than reformulated.</p>
          <div class="stats mt-l">
            <div class="stat"><div class="n">6</div><div class="l">Compositions in the house</div></div>
            <div class="stat"><div class="n">4<span style="font-size:.5em"> yrs</span></div><div class="l">Average development time</div></div>
            <div class="stat"><div class="n">100<span style="font-size:.5em">%</span></div><div class="l">Refillable vessels</div></div>
          </div>
          <a class="btn btn-ghost mt-l" href="#/about" data-link>Read Our Story</a>
        </div>
        <div data-reveal="scale">
          <div class="sc-media" style="aspect-ratio:4/5">
            <div class="parallax" data-parallax="0.07" style="position:absolute;inset:-7% 0">
              ${img('about', 'The Scentz Haven atelier', { sizes: '(max-width:860px) 92vw, 46vw' })}
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section alt tight">
    <div class="wrap">
      <div class="s-head center" data-reveal><span class="eyebrow">How It Wears</span><h2>Three notes. One arc.</h2></div>
      <div class="steps">
        <div class="step" data-reveal style="--d:0ms"><div class="num">01 — Top</div><h4>The first impression</h4><p>Bright, volatile materials that announce the fragrance in the opening minutes, then step aside.</p></div>
        <div class="step" data-reveal style="--d:110ms"><div class="num">02 — Heart</div><h4>The character</h4><p>The core accord emerges after twenty minutes and defines the fragrance for most of its life on skin.</p></div>
        <div class="step" data-reveal style="--d:220ms"><div class="num">03 — Base</div><h4>The memory</h4><p>Resins and woods that anchor everything above them — and remain hours after the rest has gone.</p></div>
      </div>
    </div>
  </section>`;
}

/* ============================================================
   COLLECTION
   ============================================================ */
export function Collection(cat) {
  const list = byCategory(cat);
  const isPerf = cat === 'perfume';
  return `
  <section class="section" style="padding-top:calc(var(--nav-h) + 64px)">
    <div class="wrap">
      <div class="s-head" data-reveal>
        <span class="eyebrow">${isPerf ? 'Fragrance' : 'Home Fragrance'}</span>
        <h2>${isPerf ? 'Perfumes' : 'Diffusers'}</h2>
        <p class="lead">${isPerf
          ? 'Four extraits and eaux de parfum, each built around a single idea and refined over years.'
          : 'Slow-release reed diffusers in hand-glazed vessels, made to be refilled rather than replaced.'}</p>
      </div>
      <div class="grid">${list.map((p, i) => productCard(p, i)).join('')}</div>
    </div>
  </section>

  <section class="section alt tight">
    <div class="wrap">
      <div class="split">
        <div data-reveal="left">
          <span class="eyebrow">Not sure where to begin?</span>
          <h2 class="display" style="font-size:clamp(28px,3.6vw,42px);margin-top:12px">Try the Discovery Set.</h2>
          <p class="lead mt-s">All six compositions in 2 ml sprays, with a credit toward your first full bottle.</p>
        </div>
        <div data-reveal="right" style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;justify-content:flex-end">
          <a class="btn" href="#/contact" data-link>Request a Set</a>
          <a class="btn btn-ghost" href="#/${isPerf ? 'diffusers' : 'perfumes'}" data-link>${isPerf ? 'View Diffusers' : 'View Perfumes'}</a>
        </div>
      </div>
    </div>
  </section>`;
}

/* ============================================================
   PRODUCT DETAIL
   ============================================================ */
export function Product(id) {
  const p = byId(id);
  if (!p) return NotFound();

  const recs = PRODUCTS.filter((x) => x.id !== p.id).slice(0, 3);
  const avg = p.rating;

  return `
  <section class="pdp">
    <div class="wrap">
      <nav class="crumbs" data-reveal="fade">
        <a href="#/" data-link>Home</a><span>/</span>
        <a href="#/${p.category === 'perfume' ? 'perfumes' : 'diffusers'}" data-link>${p.category === 'perfume' ? 'Perfumes' : 'Diffusers'}</a>
        <span>/</span><span class="muted">${esc(p.name)}</span>
      </nav>

      <div class="pdp-grid">
        <div data-reveal="fade">
          <div class="gal-main" id="gal">
            ${p.images.map((s, i) => `
              <div class="slide ${i === 0 ? 'on' : ''}" data-slide="${i}">
                ${img(s, `${p.name} — view ${i + 1}`, { sizes: '(max-width:1024px) 94vw, 56vw', eager: i === 0 })}
              </div>`).join('')}
            <button class="gal-nav prev" data-gal="-1" aria-label="Previous image">${ICON.left}</button>
            <button class="gal-nav next" data-gal="1" aria-label="Next image">${ICON.right}</button>
          </div>
          <div class="thumbs">
            ${p.images.map((s, i) => `
              <button class="${i === 0 ? 'on' : ''}" data-thumb="${i}" aria-label="View image ${i + 1}">
                <img src="assets/img/r/${s}-480.jpg" alt="" loading="lazy">
              </button>`).join('')}
          </div>
        </div>

        <div class="pdp-info" data-reveal="right">
          <span class="eyebrow">${esc(p.concentration)}</span>
          <h1>${esc(p.name)}</h1>
          <div class="rating">
            ${stars(avg)}
            <span>${avg.toFixed(1)}</span>
            <span class="muted">· ${p.reviewCount} reviews</span>
          </div>
          <div class="pdp-price" id="pdpPrice">${money(p.sizes[0].price)}</div>
          <p class="pdp-desc">${esc(p.description)}</p>

          <div class="opt-group">
            <div class="opt-label"><span>Size</span><span id="sizeHint">${esc(p.sizes[0].label)}</span></div>
            <div class="sizes" id="sizes">
              ${p.sizes.map((s, i) => `
                <button class="size ${i === 0 ? 'on' : ''}" data-size="${esc(s.label)}" data-price="${s.price}">
                  ${esc(s.label)}<span class="s-price">${money(s.price)}</span>
                </button>`).join('')}
            </div>
          </div>

          <div class="opt-group">
            <div class="opt-label"><span>Quantity</span></div>
            <div class="qty">
              <button data-q="-1" aria-label="Decrease quantity">−</button>
              <span class="n" id="qtyN">1</span>
              <button data-q="1" aria-label="Increase quantity">+</button>
            </div>
          </div>

          <div class="pdp-actions">
            <button class="btn btn-lg btn-block" id="pdpAdd">Add to Cart — <span id="addPrice">${money(p.sizes[0].price)}</span></button>
            <button class="btn btn-ghost btn-lg btn-block" id="pdpBuy">Buy Now</button>
          </div>

          <div class="accord">
            <div class="acc-item open">
              <button class="acc-head">Fragrance Notes <span class="pm"></span></button>
              <div class="acc-body"><div><div class="acc-inner">
                <dl class="note-pyramid">
                  <div class="np-row"><dt>Top</dt><dd>${p.notes.top.join(' · ')}</dd></div>
                  <div class="np-row"><dt>Heart</dt><dd>${p.notes.heart.join(' · ')}</dd></div>
                  <div class="np-row"><dt>Base</dt><dd>${p.notes.base.join(' · ')}</dd></div>
                </dl>
              </div></div></div>
            </div>
            <div class="acc-item">
              <button class="acc-head">Shipping &amp; Returns <span class="pm"></span></button>
              <div class="acc-body"><div><div class="acc-inner">
                Complimentary tracked delivery on orders above ${money(FREE_SHIP_THRESHOLD)}. Express (2–3 business days) and next-day courier available at checkout.
                Every order is packed in a linen-lined box with a hand-written note. Unopened items may be returned within 30 days at our cost.
              </div></div></div>
            </div>
            <div class="acc-item">
              <button class="acc-head">Details &amp; Care <span class="pm"></span></button>
              <div class="acc-body"><div><div class="acc-inner">
                ${esc(p.concentration)} · Expected wear ${esc(p.longevity)}. ${p.category === 'perfume'
                  ? 'Store away from direct sunlight and heat to preserve the top notes. Apply to pulse points; do not rub.'
                  : 'Invert the reeds once weekly to refresh the throw. Place away from direct sunlight, vents and open windows.'}
                Vegan, cruelty-free and IFRA certified. Vessel is refillable.
              </div></div></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section alt tight">
    <div class="wrap">
      <div class="s-head" style="margin-bottom:26px" data-reveal><span class="eyebrow">Reviews</span><h2 style="font-size:clamp(27px,3.4vw,40px)">What people say</h2></div>
      <div class="rating-summary" data-reveal="fade">
        <div class="big-score">${avg.toFixed(1)}</div>
        <div>${stars(avg, 15)}<div class="muted" style="font-size:13px;margin-top:5px">Based on ${p.reviewCount} verified purchases</div></div>
      </div>
      <div class="reviews">
        ${p.reviews.map((r, i) => `
          <div class="review" data-reveal="fade" style="--d:${i * 90}ms">
            <div class="rev-top">
              <div>
                <div class="rev-name">${esc(r.title)}</div>
                <div class="rev-meta">${esc(r.name)} · ${esc(r.loc)} · ${esc(r.date)}</div>
              </div>
              <div style="display:flex;align-items:center;gap:14px">
                ${stars(r.stars, 12)}
                <span class="verified">${ICON.check} Verified</span>
              </div>
            </div>
            <p class="rev-body">${esc(r.body)}</p>
          </div>`).join('')}
      </div>
    </div>
  </section>

  <section class="section">
    <div class="wrap">
      <div class="s-head" data-reveal><span class="eyebrow">You May Also Like</span><h2 style="font-size:clamp(27px,3.4vw,40px)">Recommended</h2></div>
      <div class="grid">${recs.map((r, i) => productCard(r, i)).join('')}</div>
    </div>
  </section>`;
}

/** PDP interactivity: gallery, sizes, qty, accordion. */
export function bindProduct(id) {
  const p = byId(id);
  if (!p) return;
  let idx = 0, qty = 1, size = p.sizes[0];

  const slides = $$('#gal .slide'), thumbs = $$('[data-thumb]');
  const show = (n) => {
    idx = (n + slides.length) % slides.length;
    slides.forEach((s, i) => s.classList.toggle('on', i === idx));
    thumbs.forEach((t, i) => t.classList.toggle('on', i === idx));
  };
  thumbs.forEach((t) => t.addEventListener('click', () => show(+t.dataset.thumb)));
  $$('[data-gal]').forEach((b) => b.addEventListener('click', () => show(idx + +b.dataset.gal)));

  // Keyboard + swipe
  document.addEventListener('keydown', (e) => {
    if (!document.contains(slides[0])) return;
    if (e.key === 'ArrowLeft') show(idx - 1);
    if (e.key === 'ArrowRight') show(idx + 1);
  });
  const gal = $('#gal');
  let x0 = null;
  gal?.addEventListener('touchstart', (e) => (x0 = e.touches[0].clientX), { passive: true });
  gal?.addEventListener('touchend', (e) => {
    if (x0 === null) return;
    const dx = e.changedTouches[0].clientX - x0;
    if (Math.abs(dx) > 45) show(idx + (dx < 0 ? 1 : -1));
    x0 = null;
  }, { passive: true });

  const sync = () => {
    $('#pdpPrice').textContent = money(size.price);
    $('#addPrice').textContent = money(size.price * qty);
    $('#sizeHint').textContent = size.label;
    $('#qtyN').textContent = qty;
  };

  $$('#sizes .size').forEach((b) => b.addEventListener('click', () => {
    $$('#sizes .size').forEach((x) => x.classList.remove('on'));
    b.classList.add('on');
    size = p.sizes.find((s) => s.label === b.dataset.size);
    sync();
  }));

  $$('[data-q]').forEach((b) => b.addEventListener('click', () => {
    qty = Math.max(1, Math.min(99, qty + +b.dataset.q));
    sync();
  }));

  $('#pdpAdd')?.addEventListener('click', () =>
    addToCart(p.id, size.label, qty, $('#gal .slide.on')));

  $('#pdpBuy')?.addEventListener('click', () => {
    cart.add(p.id, size.label, qty);
    location.hash = '#/checkout';
  });

  $$('.acc-head').forEach((h) => h.addEventListener('click', () => h.parentElement.classList.toggle('open')));
}

/* ============================================================
   ABOUT
   ============================================================ */
export function About() {
  return `
  <section class="section" style="padding-top:calc(var(--nav-h) + 64px)">
    <div class="wrap wrap-narrow center">
      <span class="eyebrow" data-reveal="fade">Our Story</span>
      <h1 class="display" style="font-size:clamp(38px,6.4vw,74px);margin-top:16px" data-reveal>
        We make scents<br>that people remember.
      </h1>
      <p class="lead mt-m" data-reveal style="--d:120ms">
        Scentz Haven began in 2016 with a single unlabelled bottle and an obsession:
        that a fragrance should not merely be noticed, but recalled — years later, without warning.
      </p>
    </div>
  </section>

  <div class="wrap">
    <div class="sc-media" style="aspect-ratio:21/9;border-radius:4px" data-reveal="scale">
      <div class="parallax" data-parallax="0.08" style="position:absolute;inset:-8% 0">
        ${img('atelier', 'The Scentz Haven atelier in Grasse', { sizes: '100vw' })}
      </div>
    </div>
  </div>

  <section class="section">
    <div class="wrap">
      <div class="split">
        <div data-reveal="left">
          <span class="eyebrow">The Beginning</span>
          <h2 class="display" style="font-size:clamp(28px,3.8vw,44px);margin-top:12px">An obsession with the thing you cannot see.</h2>
        </div>
        <div data-reveal="right">
          <p class="lead">Our founder spent a decade in interiors before realising that the most memorable rooms she had ever entered were not the most beautiful ones — they were the ones that smelled like something specific. A hotel in Kyoto. A bookshop in Lisbon. Her grandmother's hallway.</p>
          <p class="lead mt-s">Scentz Haven exists to make that effect deliberate. We compose fragrance for people and for the spaces they return to, with the conviction that both deserve the same care.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="philosophy">
    <div class="wrap">
      <blockquote>
        <span class="rise" data-reveal="fade"><span>Your scent. Your space.</span></span>
        <span class="rise" data-reveal="fade" style="--d:140ms"><span>Your haven.</span></span>
      </blockquote>
      <div class="attrib" data-reveal="fade" style="--d:400ms">The Scentz Haven Philosophy</div>
    </div>
  </section>

  <section class="section">
    <div class="wrap">
      <div class="s-head center" data-reveal><span class="eyebrow">How We Work</span><h2>Four principles.</h2></div>
      <div class="steps">
        <div class="step" data-reveal><div class="num">01</div><h4>Slowly</h4><p>An average of four years from first trial to release. If a formula is not right, it does not ship — we have shelved more compositions than we have sold.</p></div>
        <div class="step" data-reveal style="--d:100ms"><div class="num">02</div><h4>Honestly</h4><p>Full note disclosure on every product. No inflated concentrations, no reformulating quietly once a scent becomes popular.</p></div>
        <div class="step" data-reveal style="--d:200ms"><div class="num">03</div><h4>Responsibly</h4><p>Vegan and cruelty-free throughout, IFRA certified, with refillable vessels and plastic-free packaging as standard.</p></div>
        <div class="step" data-reveal style="--d:300ms"><div class="num">04</div><h4>Quietly</h4><p>No celebrity faces, no seasonal churn. Six compositions, kept in print for as long as the materials remain available.</p></div>
      </div>
    </div>
  </section>

  <section class="section alt tight">
    <div class="wrap center">
      <h2 class="display" style="font-size:clamp(27px,3.6vw,42px)" data-reveal>Find your signature.</h2>
      <p class="lead mt-s" data-reveal style="--d:100ms">Six compositions. One of them is yours.</p>
      <div class="mt-m" style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap" data-reveal style="--d:180ms">
        <a class="btn btn-lg" href="#/perfumes" data-link>Shop Perfumes</a>
        <a class="btn btn-ghost btn-lg" href="#/diffusers" data-link>Explore Diffusers</a>
      </div>
    </div>
  </section>`;
}

/* ============================================================
   CONTACT
   ============================================================ */
export function Contact() {
  return `
  <section class="section" style="padding-top:calc(var(--nav-h) + 64px)">
    <div class="wrap">
      <div class="s-head" data-reveal>
        <span class="eyebrow">Contact</span>
        <h2>We would love to hear from you.</h2>
        <p class="lead">Questions about a composition, an order, or a private commission — our team replies within one business day.</p>
      </div>

      <div class="contact-grid">
        <div data-reveal="left">
          <div class="c-item"><div class="k">Client Care</div><div class="v">care@scentzhaven.com<small>Monday – Saturday, 09:00 – 18:00 GMT</small></div></div>
          <div class="c-item"><div class="k">Telephone</div><div class="v">+233 30 000 0000<small>+33 4 93 00 00 00 (Atelier, Grasse)</small></div></div>
          <div class="c-item"><div class="k">Flagship</div><div class="v">12 Ridge Crescent, Kumasi<small>Ashanti, Ghana · By appointment</small></div></div>
          <div class="c-item" style="border:0"><div class="k">Press &amp; Wholesale</div><div class="v">press@scentzhaven.com</div></div>
        </div>

        <form id="contactForm" data-reveal="right" novalidate>
          <div class="f-grid">
            <div class="field"><input id="cName" placeholder=" " autocomplete="name"><label for="cName">Full name</label><div class="msg">Please enter your name</div></div>
            <div class="field"><input id="cEmail" type="email" placeholder=" " autocomplete="email"><label for="cEmail">Email address</label><div class="msg">Please enter a valid email</div></div>
            <div class="field full sel-wrap">
              <select id="cTopic">
                <option value="">&nbsp;</option>
                <option>An order</option><option>A fragrance recommendation</option>
                <option>Discovery set</option><option>Private commission</option>
                <option>Press or wholesale</option><option>Something else</option>
              </select>
              <label for="cTopic">How can we help?</label>
            </div>
            <div class="field full">
              <input id="cMsg" placeholder=" " style="height:120px;padding-top:28px;align-items:start">
              <label for="cMsg">Your message</label>
              <div class="msg">Please add a short message</div>
            </div>
          </div>
          <button class="btn btn-lg mt-s" type="submit">Send Message</button>
          <p class="muted" style="font-size:12.5px;margin-top:14px">By sending this message you agree to our Privacy Policy.</p>
        </form>
      </div>
    </div>
  </section>`;
}

export function bindContact() {
  const f = $('#contactForm');
  if (!f) return;
  $$('#contactForm select').forEach((s) =>
    s.addEventListener('change', () => s.classList.toggle('filled', !!s.value)));

  f.addEventListener('submit', (e) => {
    e.preventDefault();
    const checks = [
      ['#cName', (v) => v.trim().length > 1],
      ['#cEmail', (v) => /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(v.trim())],
      ['#cMsg', (v) => v.trim().length > 4]
    ];
    let ok = true, firstBad = null;
    checks.forEach(([sel, test]) => {
      const el = $(sel), good = test(el.value);
      el.closest('.field').classList.toggle('err', !good);
      if (!good && !firstBad) firstBad = el;
      ok = ok && good;
    });
    if (!ok) { firstBad?.focus(); return; }
    f.innerHTML = `<div class="center" style="padding:60px 0">
        <div class="confirm" style="padding:0"><div class="tick">${ICON.check}</div></div>
        <h3 class="display" style="font-size:30px">Message received.</h3>
        <p class="lead mt-s">Thank you — we will reply within one business day.</p>
      </div>`;
  });
}

/* ============================================================
   CHECKOUT
   ============================================================ */
export function Checkout() {
  const lines = cart.detailed();
  if (!lines.length) {
    return `<section class="section" style="padding-top:calc(var(--nav-h) + 90px)">
      <div class="wrap center">
        <div class="empty">${ICON.bag}
          <h2 class="display" style="font-size:34px;margin-top:14px">Your bag is empty</h2>
          <p>Add a fragrance to begin checkout.</p>
          <a class="btn" href="#/perfumes" data-link>Discover Fragrances</a>
        </div>
      </div></section>`;
  }

  return `
  <section class="checkout">
    <div class="wrap">
      <div class="co-steps" data-reveal="fade">
        <span class="st on">Bag</span><span class="sep"></span>
        <span class="st on">Details</span><span class="sep"></span>
        <span class="st">Confirmation</span>
      </div>
      <h1 class="display" style="font-size:clamp(32px,4.4vw,50px);margin-bottom:34px" data-reveal>Checkout</h1>

      <div class="co-grid">
        <form id="coForm" novalidate data-reveal="left">
          <fieldset>
            <legend>Contact</legend>
            <div class="f-grid">
              <div class="field full"><input id="fEmail" type="email" placeholder=" " autocomplete="email"><label for="fEmail">Email address</label><div class="msg">Enter a valid email</div></div>
            </div>
          </fieldset>

          <fieldset>
            <legend>Delivery Address</legend>
            <div class="f-grid">
              <div class="field"><input id="fFirst" placeholder=" " autocomplete="given-name"><label for="fFirst">First name</label><div class="msg">Required</div></div>
              <div class="field"><input id="fLast" placeholder=" " autocomplete="family-name"><label for="fLast">Last name</label><div class="msg">Required</div></div>
              <div class="field full"><input id="fAddr" placeholder=" " autocomplete="street-address"><label for="fAddr">Street address</label><div class="msg">Required</div></div>
              <div class="field"><input id="fCity" placeholder=" " autocomplete="address-level2"><label for="fCity">City</label><div class="msg">Required</div></div>
              <div class="field"><input id="fZip" placeholder=" " autocomplete="postal-code"><label for="fZip">Postal code</label><div class="msg">Required</div></div>
              <div class="field full sel-wrap">
                <select id="fCountry" autocomplete="country-name">
                  <option value="">&nbsp;</option>
                  <option>Ghana</option><option>Nigeria</option><option>United Kingdom</option>
                  <option>United States</option><option>France</option><option>United Arab Emirates</option>
                  <option>Canada</option><option>Australia</option><option>Singapore</option>
                </select>
                <label for="fCountry">Country / Region</label>
                <div class="msg">Select a country</div>
              </div>
            </div>
          </fieldset>

          <fieldset>
            <legend>Delivery Method</legend>
            <div class="ship-opts" id="shipOpts">
              ${SHIPPING.map((s) => {
                const free = s.id === 'standard' && cart.freeShipEarned;
                return `
                <label class="ship-opt ${cart.ship === s.id ? 'on' : ''}" data-ship="${s.id}">
                  <span class="radio"></span>
                  <span><span class="so-name">${esc(s.name)}</span><span class="so-sub">${esc(s.sub)}</span></span>
                  <span class="so-price">${free
                    ? `<span class="free">Complimentary</span> <s style="opacity:.4">${money(s.price)}</s>`
                    : money(s.price)}</span>
                </label>`; }).join('')}
            </div>
          </fieldset>

          <fieldset>
            <legend>Payment</legend>
            <div class="f-grid">
              <div class="field full"><input id="fCard" placeholder=" " inputmode="numeric" autocomplete="cc-number"><label for="fCard">Card number</label><div class="msg">Enter a 16-digit card number</div></div>
              <div class="field"><input id="fExp" placeholder=" " inputmode="numeric" autocomplete="cc-exp"><label for="fExp">MM / YY</label><div class="msg">Required</div></div>
              <div class="field"><input id="fCvc" placeholder=" " inputmode="numeric" autocomplete="cc-csc"><label for="fCvc">CVC</label><div class="msg">Required</div></div>
            </div>
            <p class="muted" style="font-size:12.5px;margin-top:12px;display:flex;gap:8px;align-items:center">
              ${ICON.lock} This is a demonstration store — no payment is processed and no card data is stored.
            </p>
          </fieldset>

          <button class="btn btn-lg btn-block" type="submit" id="payBtn">Pay ${money(cart.total)}</button>
          <p class="center muted" style="font-size:12.5px;margin-top:14px">
            <a class="tlink" href="#/perfumes" data-link>Continue shopping</a>
          </p>
        </form>

        <aside class="summary" data-reveal="right" id="coSummary">${summaryHTML()}</aside>
      </div>
    </div>
  </section>`;
}

function summaryHTML() {
  const lines = cart.detailed();
  return `
    <h3>Order Summary</h3>
    ${lines.map((l) => `
      <div class="sum-line">
        <div class="s-img"><img src="assets/img/r/${l.product.images[0]}-480.jpg" alt=""><span class="s-q">${l.qty}</span></div>
        <div><div class="s-n">${esc(l.product.name)}</div><div class="s-v">${esc(l.size)}</div></div>
        <div class="s-p">${money(l.total)}</div>
      </div>`).join('')}
    <div class="hr" style="margin:16px 0"></div>
    <div class="totals" style="margin:0">
      <div class="t-row"><span>Subtotal</span><span>${money(cart.subtotal)}</span></div>
      <div class="t-row"><span>Shipping</span><span class="${cart.shipping === 0 ? 'free' : ''}">${cart.shipping === 0 ? 'Complimentary' : money(cart.shipping)}</span></div>
      <div class="t-row grand"><span>Total</span><span>${money(cart.total)}</span></div>
    </div>
    <div class="trust">
      <div>${ICON.truck}<span>Tracked, insured delivery in linen-lined packaging.</span></div>
      <div>${ICON.gift}<span>Complimentary gift wrapping and hand-written note.</span></div>
      <div>${ICON.leaf}<span>Vegan, cruelty-free and refillable by design.</span></div>
      <div>${ICON.lock}<span>Secure encrypted checkout.</span></div>
    </div>`;
}

export function bindCheckout() {
  const f = $('#coForm');
  if (!f) return;

  $$('#coForm select').forEach((s) =>
    s.addEventListener('change', () => s.classList.toggle('filled', !!s.value)));

  const refresh = () => {
    $('#coSummary').innerHTML = summaryHTML();
    const btn = $('#payBtn');
    if (btn) btn.textContent = `Pay ${money(cart.total)}`;
  };

  $$('[data-ship]').forEach((el) => el.addEventListener('click', () => {
    $$('[data-ship]').forEach((x) => x.classList.remove('on'));
    el.classList.add('on');
    cart.ship = el.dataset.ship;
    cart.save();
    refresh();
  }));

  // Light input masks
  const card = $('#fCard');
  card?.addEventListener('input', () => {
    card.value = card.value.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();
  });
  const exp = $('#fExp');
  exp?.addEventListener('input', () => {
    const v = exp.value.replace(/\D/g, '').slice(0, 4);
    exp.value = v.length > 2 ? `${v.slice(0, 2)} / ${v.slice(2)}` : v;
  });
  const cvc = $('#fCvc');
  cvc?.addEventListener('input', () => (cvc.value = cvc.value.replace(/\D/g, '').slice(0, 4)));

  f.addEventListener('submit', (e) => {
    e.preventDefault();
    const checks = [
      ['#fEmail', (v) => /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(v.trim())],
      ['#fFirst', (v) => v.trim().length > 1],
      ['#fLast', (v) => v.trim().length > 1],
      ['#fAddr', (v) => v.trim().length > 4],
      ['#fCity', (v) => v.trim().length > 1],
      ['#fZip', (v) => v.trim().length > 2],
      ['#fCountry', (v) => !!v],
      ['#fCard', (v) => v.replace(/\D/g, '').length === 16],
      ['#fExp', (v) => v.replace(/\D/g, '').length === 4],
      ['#fCvc', (v) => v.replace(/\D/g, '').length >= 3]
    ];
    let ok = true, firstBad = null;
    checks.forEach(([sel, test]) => {
      const el = $(sel), good = test(el.value);
      el.closest('.field').classList.toggle('err', !good);
      if (!good && !firstBad) firstBad = el;
      ok = ok && good;
    });
    if (!ok) {
      firstBad?.focus();
      firstBad?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    const btn = $('#payBtn');
    btn.disabled = true;
    btn.textContent = 'Processing…';
    const order = {
      ref: 'SH-' + Math.random().toString(36).slice(2, 8).toUpperCase(),
      email: $('#fEmail').value.trim(),
      name: $('#fFirst').value.trim(),
      total: cart.total,
      ship: cart.shipOption().name
    };
    sessionStorage.setItem('scentz.order', JSON.stringify(order));
    setTimeout(() => { cart.clear(); location.hash = '#/confirmed'; }, 1050);
  });
}

/* ============================================================
   CONFIRMATION / LEGAL / 404
   ============================================================ */
export function Confirmed() {
  let o = {};
  try { o = JSON.parse(sessionStorage.getItem('scentz.order')) || {}; } catch {}
  return `
  <section class="confirm">
    <div class="wrap wrap-narrow">
      <div class="tick">${ICON.check}</div>
      <span class="eyebrow">Order ${esc(o.ref || 'SH-XXXXXX')}</span>
      <h1 style="margin-top:14px">Thank you${o.name ? ', ' + esc(o.name) : ''}.</h1>
      <p class="lead mt-s">Your order is confirmed. A receipt is on its way to <strong>${esc(o.email || 'your inbox')}</strong>, and you will receive tracking as soon as it leaves our atelier.</p>
      <div class="mt-m" style="display:inline-flex;gap:10px;flex-wrap:wrap;justify-content:center">
        <a class="btn" href="#/" data-link>Return Home</a>
        <a class="btn btn-ghost" href="#/perfumes" data-link>Continue Shopping</a>
      </div>
      <div class="mt-l muted" style="font-size:13.5px">${esc(o.ship || 'Complimentary Delivery')}${o.total ? ' · ' + money(o.total) : ''}</div>
    </div>
  </section>`;
}

export function Legal(kind) {
  const privacy = kind === 'privacy';
  const body = privacy ? [
    ['What we collect', 'We collect only what is required to fulfil an order and to answer your questions: your name, delivery address, email address and order history. Payment details are handled by our payment processor and never stored on our servers.'],
    ['How we use it', 'To process and deliver orders, to respond to enquiries, and — only where you have opted in — to send occasional letters about new compositions. We do not sell or rent personal data to anyone, ever.'],
    ['Cookies', 'This site stores your bag contents in your browser so it survives a refresh. It sets no advertising or third-party tracking cookies.'],
    ['Your rights', 'You may request a copy of your data, ask us to correct it, or ask us to erase it entirely by writing to care@scentzhaven.com. We respond within 30 days.'],
    ['Retention', 'Order records are kept for seven years to meet accounting obligations. Marketing preferences are kept until you withdraw them.']
  ] : [
    ['Orders', 'An order constitutes an offer to purchase. A contract is formed when we send dispatch confirmation. We reserve the right to decline an order where a product is unavailable or a pricing error has occurred.'],
    ['Pricing', 'All prices are shown in US dollars and include applicable duties for listed destinations. Shipping is calculated at checkout and is complimentary on standard delivery above $250.'],
    ['Returns', 'Unopened items may be returned within 30 days of delivery for a full refund, at our cost. For hygiene reasons, opened fragrances can only be returned if faulty. Discovery sets are non-returnable.'],
    ['Delivery', 'Estimated delivery windows are indicative and begin from dispatch. Risk passes to you on delivery. We are not liable for delays caused by customs or courier disruption.'],
    ['Liability', 'Nothing in these terms limits liability for death, personal injury or fraud. Otherwise our liability is limited to the value of the order concerned.']
  ];

  return `
  <section class="section" style="padding-top:calc(var(--nav-h) + 64px)">
    <div class="wrap wrap-narrow">
      <span class="eyebrow" data-reveal="fade">Legal</span>
      <h1 class="display" style="font-size:clamp(32px,4.6vw,52px);margin-top:14px" data-reveal>${privacy ? 'Privacy Policy' : 'Terms &amp; Conditions'}</h1>
      <p class="muted mt-s" data-reveal="fade">Last updated 1 August 2026</p>
      <div class="mt-l">
        ${body.map(([h, t], i) => `
          <div data-reveal style="--d:${i * 70}ms;margin-bottom:34px">
            <h3 style="font-size:18px;font-weight:500">${esc(h)}</h3>
            <p class="lead" style="font-size:16px;margin-top:10px">${esc(t)}</p>
          </div>`).join('')}
      </div>
      <div class="hr mt-l"></div>
      <p class="muted mt-m" style="font-size:14px">Questions about this policy? Write to <a class="tlink" href="#/contact" data-link>care@scentzhaven.com</a>.</p>
    </div>
  </section>`;
}

export function NotFound() {
  return `
  <section class="section center" style="padding-top:calc(var(--nav-h) + 110px);padding-bottom:130px">
    <div class="wrap wrap-narrow">
      <span class="eyebrow">404</span>
      <h1 class="display" style="font-size:clamp(34px,5vw,58px);margin-top:14px">This page has evaporated.</h1>
      <p class="lead mt-s">The page you are looking for does not exist — but the collection is right this way.</p>
      <div class="mt-m" style="display:inline-flex;gap:10px;flex-wrap:wrap;justify-content:center">
        <a class="btn" href="#/" data-link>Return Home</a>
        <a class="btn btn-ghost" href="#/perfumes" data-link>Shop Perfumes</a>
      </div>
    </div>
  </section>`;
}
